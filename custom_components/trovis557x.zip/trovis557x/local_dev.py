"""Local development settings.

This file is intentionally gitignored.
"""

LOCAL_TROVIS_MODBUS_SRC = "/config/dev/trovis-modbus/src"
